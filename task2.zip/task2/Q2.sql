CREATE TABLE User (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    contact VARCHAR(10),
    password VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Post (
    post_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    user_id INT NOT NULL,

 -- Foreign Key: Post belongs to User
    FOREIGN KEY (user_id) REFERENCES User(user_id)
        ON DELETE CASCADE

CREATE TABLE Category (
    category_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) UNIQUE NOT NULL
);

CREATE TABLE Post_Category (
    post_id INT,
    category_id INT,

    PRIMARY KEY (post_id, category_id),

    FOREIGN KEY (post_id) REFERENCES Post(post_id)
        ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES Category(category_id)
        ON DELETE CASCADE
);


CREATE TABLE Comment (
    comment_id INT PRIMARY KEY AUTO_INCREMENT,
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    post_id INT NOT NULL,
    user_id INT NOT NULL,

    FOREIGN KEY (post_id) REFERENCES Post(post_id)
        ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES User(user_id)
        ON DELETE CASCADE
);


CREATE TABLE Like (
    like_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    post_id INT NOT NULL,

    -- Foreign Keys
    FOREIGN KEY (user_id) REFERENCES User(user_id)
        ON DELETE CASCADE,
    FOREIGN KEY (post_id) REFERENCES Post(post_id)
        ON DELETE CASCADE,

    UNIQUE (user_id, post_id)
);


INSERT INTO User (username, contact, password)
VALUES ('vasu', '9876543210', 'hashed_password');

INSERT INTO Post (title, user_id)
VALUES ('My First Blog', 1);

INSERT INTO Category (name)
VALUES ('Technology');

INSERT INTO Post_Category (post_id, category_id)
VALUES (1, 1);

INSERT INTO Comment (content, post_id, user_id)
VALUES ('Great post!', 1, 1);

INSERT INTO Like (user_id, post_id)
VALUES (1, 1);

  --QUERIES
  
-- Get all posts with author name
SELECT p.post_id, p.title, u.username
FROM Post p
JOIN User u ON p.user_id = u.user_id;

-- Get all comments for a post
SELECT c.content, u.username
FROM Comment c
JOIN User u ON c.user_id = u.user_id
WHERE c.post_id = 1;

-- Get categories of a post
SELECT cat.name
FROM Category cat
JOIN Post_Category pc ON cat.category_id = pc.category_id
WHERE pc.post_id = 1;

-- Count likes per post
SELECT post_id, COUNT(*) AS total_likes
FROM Like
GROUP BY post_id;
